const express = require("express"); // Importing express
const {
  allMessages,
  sendMessage,
} = require("../controllers/messageControllers"); // Importing message controllers
const { protect } = require("../middleware/authMiddleware"); // Importing authentication middleware

const router = express.Router(); // Creating an express router

// Routes for message functionalities
router.route("/:chatId").get(protect, allMessages); // Route to get all messages for a chat
router.route("/").post(protect, sendMessage); // Route to create a new message

module.exports = router; // Exporting the router
