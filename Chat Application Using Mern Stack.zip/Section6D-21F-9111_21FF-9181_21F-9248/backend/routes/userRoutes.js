const express = require("express"); // Importing express
const {
  registerUser,
  authUser,
  allUsers,
} = require("../controllers/userControllers"); // Importing user controllers
const { protect } = require("../middleware/authMiddleware"); // Importing authentication middleware

const router = express.Router(); // Creating an express router

// Routes for user functionalities
router.route("/").get(protect, allUsers); // Route to get all users
router.route("/").post(registerUser); // Route to register a new user
router.post("/login", authUser); // Route to authenticate a user

module.exports = router; // Exporting the router
