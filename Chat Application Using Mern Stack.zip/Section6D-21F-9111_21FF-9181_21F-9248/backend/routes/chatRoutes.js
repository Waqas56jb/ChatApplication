const express = require("express"); // Importing express
const {
  accessChat,
  fetchChats,
  createGroupChat,
  removeFromGroup,
  addToGroup,
  renameGroup,
} = require("../controllers/chatControllers"); // Importing chat controllers
const { protect } = require("../middleware/authMiddleware"); // Importing authentication middleware

const router = express.Router(); // Creating an express router

// Routes for chat functionalities
router.route("/").post(protect, accessChat); // Route to create or fetch one-to-one chat
router.route("/").get(protect, fetchChats); // Route to fetch all chats for a user
router.route("/group").post(protect, createGroupChat); // Route to create a new group chat
router.route("/rename").put(protect, renameGroup); // Route to rename a group chat
router.route("/groupremove").put(protect, removeFromGroup); // Route to remove a user from a group
router.route("/groupadd").put(protect, addToGroup); // Route to add a user to a group

module.exports = router; // Exporting the router
