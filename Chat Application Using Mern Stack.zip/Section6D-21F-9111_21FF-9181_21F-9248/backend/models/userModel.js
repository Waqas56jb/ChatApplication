// Importing mongoose for schema creation
const mongoose = require("mongoose");
// Importing bcrypt for password hashing
const bcrypt = require("bcryptjs");

// Creating a user schema
const userSchema = mongoose.Schema(
  {
    name: { type: "String", required: true }, // Name of the user
    email: { type: "String", unique: true, required: true }, // Email of the user
    password: { type: "String", required: true }, // Password of the user
    pic: {
      type: "String",
      required: true,
      default:
        "https://icon-library.com/images/anonymous-avatar-icon/anonymous-avatar-icon-25.jpg", // Default profile picture URL
    },
    isAdmin: {
      type: Boolean,
      required: true,
      default: false, // Default role of the user
    },
  },
  { timestamps: true } // Adds createdAt and updatedAt timestamps
);

// Method to compare entered password with stored hashed password
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Middleware to hash the password before saving
userSchema.pre("save", async function (next) {
  if (!this.isModified) {
    next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Creating the User model using the schema
const User = mongoose.model("User", userSchema);

module.exports = User; // Exporting the User model
