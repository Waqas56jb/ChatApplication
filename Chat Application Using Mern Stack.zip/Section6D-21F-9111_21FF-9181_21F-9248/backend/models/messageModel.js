// Importing mongoose for schema creation
const mongoose = require("mongoose");

// Creating a message schema
const messageSchema = mongoose.Schema(
  {
    sender: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // Sender of the message
    content: { type: String, trim: true }, // Content of the message
    chat: { type: mongoose.Schema.Types.ObjectId, ref: "Chat" }, // Chat to which the message belongs
    readBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }], // Users who have read the message
  },
  { timestamps: true } // Adds createdAt and updatedAt timestamps
);

// Creating the Message model using the schema
const Message = mongoose.model("Message", messageSchema);

module.exports = Message; // Exporting the Message model
