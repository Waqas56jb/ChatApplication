// Importing mongoose for schema creation
const mongoose = require("mongoose");

// Creating a chat schema
const chatModel = mongoose.Schema(
  {
    chatName: { type: String, trim: true }, // Name of the chat
    isGroupChat: { type: Boolean, default: false }, // Indicates if it's a group chat or not
    users: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }], // Users participating in the chat
    latestMessage: { // Reference to the latest message in the chat
      type: mongoose.Schema.Types.ObjectId,
      ref: "Message",
    },
    groupAdmin: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // Admin of the group chat
  },
  { timestamps: true } // Adds createdAt and updatedAt timestamps
);

// Creating the Chat model using the schema
const Chat = mongoose.model("Chat", chatModel);

module.exports = Chat; // Exporting the Chat model
