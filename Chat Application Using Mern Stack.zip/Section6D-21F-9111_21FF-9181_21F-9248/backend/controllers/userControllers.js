const asyncHandler = require("express-async-handler");  // Import express-async-handler for handling async errors
const User = require("../models/userModel");  // Import User model
const generateToken = require("../config/generateToken");  // Import generateToken function

//@description     Get or Search all users
//@route           GET /api/user?search=
//@access          Public
const allUsers = asyncHandler(async (req, res) => {
  // Define a keyword for searching users based on name or email
  const keyword = req.query.search
    ? {
        $or: [
          { name: { $regex: req.query.search, $options: "i" } },
          { email: { $regex: req.query.search, $options: "i" } },
        ],
      }
    : {};

  // Find all users excluding the current user
  const users = await User.find(keyword).find({ _id: { $ne: req.user._id } });
  res.send(users);  // Send the users
});

//@description     Register new user
//@route           POST /api/user/
//@access          Public
const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password, pic } = req.body;  // Extract name, email, password, and pic from request body

  if (!name || !email || !password) {  // Check if name, email, or password is missing
    res.status(400);
    throw new Error("Please Enter all the Feilds");
  }

  const userExists = await User.findOne({ email });  // Check if user with the same email exists

  if (userExists) {  // If user exists, throw an error
    res.status(400);
    throw new Error("User already exists");
  }

  // Create a new user
  const user = await User.create({
    name,
    email,
    password,
    pic,
  });

  if (user) {  // If user is created successfully, send back user details along with a token
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      pic: user.pic,
      token: generateToken(user._id),
    });
  } else {  // If user creation fails, throw an error
    res.status(400);
    throw new Error("User not found");
  }
});

//@description     Auth the user
//@route           POST /api/users/login
//@access          Public
const authUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;  // Extract email and password from request body

  const user = await User.findOne({ email });  // Find user by email

  // Check if user exists and the password matches
  if (user && (await user.matchPassword(password))) {
    // If authentication is successful, send back user details along with a token
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      isAdmin: user.isAdmin,
      pic: user.pic,
      token: generateToken(user._id),
    });
  } else {  // If authentication fails, throw an error
    res.status(401);
    throw new Error("Invalid Email or Password");
  }
});

module.exports = { allUsers, registerUser, authUser };  // Export the functions
