const asyncHandler = require("express-async-handler");  // Import express-async-handler for handling async errors
const Chat = require("../models/chatModel");  // Import Chat model
const User = require("../models/userModel");  // Import User model

//@description     Create or fetch One to One Chat
//@route           POST /api/chat/
//@access          Protected
const accessChat = asyncHandler(async (req, res) => {
  const { userId } = req.body;  // Extract userId from request body

  if (!userId) {  // Check if userId is missing
    console.log("UserId param not sent with request");
    return res.sendStatus(400);  // Send bad request status
  }

  // Find a chat where the current user and the userId are both participants
  var isChat = await Chat.find({
    isGroupChat: false,
    $and: [
      { users: { $elemMatch: { $eq: req.user._id } } },
      { users: { $elemMatch: { $eq: userId } } },
    ],
  })
    .populate("users", "-password")  // Populate users field excluding password
    .populate("latestMessage");  // Populate latestMessage field

  isChat = await User.populate(isChat, {
    path: "latestMessage.sender",
    select: "name pic email",
  });

  if (isChat.length > 0) {
    res.send(isChat[0]);  // Send the existing chat if found
  } else {
    // Create a new chat if no existing chat is found
    var chatData = {
      chatName: "sender",
      isGroupChat: false,
      users: [req.user._id, userId],
    };

    try {
      const createdChat = await Chat.create(chatData);  // Create new chat
      const FullChat = await Chat.findOne({ _id: createdChat._id }).populate(
        "users",
        "-password"
      );
      res.status(200).json(FullChat);  // Send the newly created chat
    } catch (error) {
      res.status(400);
      throw new Error(error.message);  // Throw an error if creation fails
    }
  }
});

//@description     Fetch all chats for a user
//@route           GET /api/chat/
//@access          Protected
const fetchChats = asyncHandler(async (req, res) => {
  try {
    // Find all chats where the current user is a participant
    Chat.find({ users: { $elemMatch: { $eq: req.user._id } } })
      .populate("users", "-password")  // Populate users field excluding password
      .populate("groupAdmin", "-password")  // Populate groupAdmin field excluding password
      .populate("latestMessage")  // Populate latestMessage field
      .sort({ updatedAt: -1 })  // Sort by updatedAt in descending order
      .then(async (results) => {
        results = await User.populate(results, {
          path: "latestMessage.sender",
          select: "name pic email",
        });
        res.status(200).send(results);  // Send the results
      });
  } catch (error) {
    res.status(400);
    throw new Error(error.message);  // Throw an error if fetching fails
  }
});

//@description     Create New Group Chat
//@route           POST /api/chat/group
//@access          Protected
const createGroupChat = asyncHandler(async (req, res) => {
  if (!req.body.users || !req.body.name) {  // Check if users or name is missing
    return res.status(400).send({ message: "Please Fill all the feilds" });
  }

  var users = JSON.parse(req.body.users);  // Parse users from string to array

  if (users.length < 2) {
    return res
      .status(400)
      .send("More than 2 users are required to form a group chat");
  }

  users.push(req.user);  // Add the current user to the users array

  try {
    // Create a new group chat
    const groupChat = await Chat.create({
      chatName: req.body.name,
      users: users,
      isGroupChat: true,
      groupAdmin: req.user,
    });

    // Populate and send the newly created group chat
    const fullGroupChat = await Chat.findOne({ _id: groupChat._id })
      .populate("users", "-password")
      .populate("groupAdmin", "-password");

    res.status(200).json(fullGroupChat);
  } catch (error) {
    res.status(400);
    throw new Error(error.message);  // Throw an error if creation fails
  }
});

// @desc    Rename Group
// @route   PUT /api/chat/rename
// @access  Protected
const renameGroup = asyncHandler(async (req, res) => {
  const { chatId, chatName } = req.body;  // Extract chatId and chatName from request body

  // Update the chat's name
  const updatedChat = await Chat.findByIdAndUpdate(
    chatId,
    {
      chatName: chatName,
    },
    {
      new: true,
    }
  )
    .populate("users", "-password")  // Populate users field excluding password
    .populate("groupAdmin", "-password");  // Populate groupAdmin field excluding password

  if (!updatedChat) {
    res.status(404);
    throw new Error("Chat Not Found");  // Throw an error if chat is not found
  } else {
    res.json(updatedChat);  // Send the updated chat
  }
});

// @desc    Remove user from Group
// @route   PUT /api/chat/groupremove
// @access  Protected
const removeFromGroup = asyncHandler(async (req, res) => {
  const { chatId, userId } = req.body;  // Extract chatId and userId from request body

  // Remove the user from the chat's users array
  const removed = await Chat.findByIdAndUpdate(
    chatId,
    {
      $pull: { users: userId },
    },
    {
      new: true,
    }
  )
    .populate("users", "-password")  // Populate users field excluding password
    .populate("groupAdmin", "-password");  // Populate groupAdmin field excluding password

  if (!removed) {
    res.status(404);
    throw new Error("Chat Not Found");  // Throw an error if chat is not found
  } else {
    res.json(removed);  // Send the updated chat
  }
});

// @desc    Add user to Group / Leave
// @route   PUT /api/chat/groupadd
// @access  Protected
const addToGroup = asyncHandler(async (req, res) => {
  const { chatId, userId } = req.body;  // Extract chatId and userId from request body

  // Add the user to the chat's users array
  const added = await Chat.findByIdAndUpdate(
    chatId,
    {
      $push: { users: userId },
    },
    {
      new: true,
    }
  )
    .populate("users", "-password")  // Populate users field excluding password
    .populate("groupAdmin", "-password");  // Populate groupAdmin field excluding password

  if (!added) {
    res.status(404);
    throw new Error("Chat Not Found");  // Throw an error if chat is not found
  } else {
    res.json(added);  // Send the updated chat
  }
});

module.exports = {
  accessChat,
  fetchChats,
  createGroupChat,
  renameGroup,
  addToGroup,
  removeFromGroup,
};
