const asyncHandler = require("express-async-handler");  // Import express-async-handler for handling async errors
const Message = require("../models/messageModel");  // Import Message model
const User = require("../models/userModel");  // Import User model
const Chat = require("../models/chatModel");  // Import Chat model

//@description     Get all Messages
//@route           GET /api/Message/:chatId
//@access          Protected
const allMessages = asyncHandler(async (req, res) => {
  try {
    // Find all messages in a specific chat
    const messages = await Message.find({ chat: req.params.chatId })
      .populate("sender", "name pic email")  // Populate sender field with name, pic, email
      .populate("chat");  // Populate chat field

    res.json(messages);  // Send the messages
  } catch (error) {
    res.status(400);
    throw new Error(error.message);  // Throw an error if fetching fails
  }
});

//@description     Create New Message
//@route           POST /api/Message/
//@access          Protected
const sendMessage = asyncHandler(async (req, res) => {
  const { content, chatId } = req.body;  // Extract content and chatId from request body

  if (!content || !chatId) {  // Check if content or chatId is missing
    console.log("Invalid data passed into request");
    return res.sendStatus(400);
  }

  // Create a new message
  var newMessage = {
    sender: req.user._id,
    content: content,
    chat: chatId,
  };

  try {
    var message = await Message.create(newMessage);  // Create the message

    // Populate the message fields
    message = await message.populate("sender", "name pic").execPopulate();
    message = await message.populate("chat").execPopulate();
    message = await User.populate(message, {
      path: "chat.users",
      select: "name pic email",
    });

    // Update the latestMessage field of the chat
    await Chat.findByIdAndUpdate(req.body.chatId, { latestMessage: message });

    res.json(message);  // Send the message
  } catch (error) {
    res.status(400);
    throw new Error(error.message);  // Throw an error if creation fails
  }
});

module.exports = { allMessages, sendMessage };  // Export the functions
