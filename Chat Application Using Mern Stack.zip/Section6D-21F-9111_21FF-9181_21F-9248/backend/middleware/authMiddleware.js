const jwt = require("jsonwebtoken"); // Importing JWT for token verification
const User = require("../models/userModel.js"); // Importing User model
const asyncHandler = require("express-async-handler"); // Importing asyncHandler for handling asynchronous functions

// Middleware to protect routes that require authentication
const protect = asyncHandler(async (req, res, next) => {
  let token;

  // Check if the authorization header is present and starts with "Bearer"
  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    try {
      // Extract the token from the authorization header
      token = req.headers.authorization.split(" ")[1];

      // Verify the token
      const decoded = jwt.verify(token, process.env.JWT_SECRET);

      // Find the user based on the decoded token id and exclude the password field
      req.user = await User.findById(decoded.id).select("-password");

      // Continue to the next middleware
      next();
    } catch (error) {
      // Return an error if the token is invalid or expired
      res.status(401);
      throw new Error("Not authorized, token failed");
    }
  }

  // Return an error if no token is found in the authorization header
  if (!token) {
    res.status(401);
    throw new Error("Not authorized, no token");
  }
});

module.exports = { protect }; // Export the protect middleware
