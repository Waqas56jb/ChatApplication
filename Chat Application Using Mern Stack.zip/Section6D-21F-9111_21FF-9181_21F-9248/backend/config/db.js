// Import mongoose for MongoDB connection
const mongoose = require("mongoose");
// Import colors for colorful console logs
const colors = require("colors");

// Function to connect to MongoDB
const connectDB = async () => {
  try {
    // Connect to MongoDB using the MONGO_URI from environment variables
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    // Log successful connection
    console.log(`MongoDB Connected: ${conn.connection.host}`.cyan.underline);
  } catch (error) {
    // Log and exit with an error status code if connection fails
    console.error(`Error: ${error.message}`.red.bold);
    process.exit(1); // Exit with a non-zero status code to indicate an error
  }
};

// Export the connectDB function
module.exports = connectDB;
