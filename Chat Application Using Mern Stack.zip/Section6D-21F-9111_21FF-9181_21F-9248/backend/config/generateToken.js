// Import the jsonwebtoken library
const jwt = require("jsonwebtoken");

// Function to generate a JWT token
const generateToken = (id) => {
  // Sign the token with the user's ID and JWT_SECRET from environment variables, set to expire in 30 days
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: "30d",
  });
};

// Export the generateToken function
module.exports = generateToken;
